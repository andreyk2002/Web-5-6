package by.fpmi.web.server;

import java.io.*;
import java.net.Socket;

public class ClientRunner {
    private Socket socket;
    private BufferedReader in;
    private BufferedWriter out;
    private long id;

    private static final String ADDRESS = "localhost";
    private static final int PORT = 13666;

    public ClientRunner(long id) {
        try {
            this.id = id;
            this.socket = new Socket(ADDRESS, PORT);
            in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            out = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
        } catch (IOException e) {
            ClientRunner.this.shutdown();
        }
    }

    public void start() {
        new MessageReader().start();
    }


    private void shutdown() {
        try {
            if (!socket.isClosed()) {
                socket.close();
                in.close();
                out.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private class MessageReader extends Thread {
        @Override
        public void run() {
            String string;
            try {
                while (true) {
                    string = in.readLine();
                    System.out.printf("Message for client %d - %s%n", id, string);
                    if (string.equals("q")) {
                        ClientRunner.this.shutdown();
                        break;
                    }
                }
            } catch (IOException e) {
                ClientRunner.this.shutdown();
            }
        }
    }

    public Socket getSocket() {
        return socket;
    }
}
